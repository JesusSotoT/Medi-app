-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mvclite2
-- ------------------------------------------------------
-- Server version	5.6.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administradores`
--

DROP TABLE IF EXISTS `administradores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administradores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nombres` varchar(255) DEFAULT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `movil` varchar(45) DEFAULT NULL,
  `bloquear_acceso` tinyint(1) NOT NULL DEFAULT '0',
  `departamentos_id` int(11) NOT NULL,
  `imagenes_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`departamentos_id`),
  UNIQUE KEY `emial_UNIQUE` (`email`),
  KEY `fk_administradores_departamentos1_idx` (`departamentos_id`),
  CONSTRAINT `fk_administradores_departamentos1` FOREIGN KEY (`departamentos_id`) REFERENCES `departamentos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradores`
--

LOCK TABLES `administradores` WRITE;
/*!40000 ALTER TABLE `administradores` DISABLE KEYS */;
INSERT INTO `administradores` VALUES (2,'dani@sustam.com','948d58c95918983789f66b2f58374389','Daniel Lepe','','',0,1,328),(12,'admin@sustam.com','948d58c95918983789f66b2f58374389','SUSTAM','','',0,1,329);
/*!40000 ALTER TABLE `administradores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administradores_has_permisos`
--

DROP TABLE IF EXISTS `administradores_has_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administradores_has_permisos` (
  `administradores_id` int(11) NOT NULL,
  `permisos_id` int(11) NOT NULL,
  `permiso` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`administradores_id`,`permisos_id`),
  KEY `fk_administradores_has_permisos_permisos1_idx` (`permisos_id`),
  KEY `fk_administradores_has_permisos_administradores1_idx` (`administradores_id`),
  CONSTRAINT `fk_administradores_has_permisos_administradores1` FOREIGN KEY (`administradores_id`) REFERENCES `administradores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_administradores_has_permisos_permisos1` FOREIGN KEY (`permisos_id`) REFERENCES `permisos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradores_has_permisos`
--

LOCK TABLES `administradores_has_permisos` WRITE;
/*!40000 ALTER TABLE `administradores_has_permisos` DISABLE KEYS */;
/*!40000 ALTER TABLE `administradores_has_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuraciones`
--

DROP TABLE IF EXISTS `configuraciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuraciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` text NOT NULL,
  `clave` varchar(45) NOT NULL,
  `valor` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuraciones`
--

LOCK TABLES `configuraciones` WRITE;
/*!40000 ALTER TABLE `configuraciones` DISABLE KEYS */;
INSERT INTO `configuraciones` VALUES (1,'Correo de notificaciones','infoMail','dani@sustam.com');
/*!40000 ALTER TABLE `configuraciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departamentos`
--

DROP TABLE IF EXISTS `departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departamentos`
--

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` VALUES (1,'Administradores','Administradores Generales'),(2,'Agentes','Agentes'),(3,'Proveedores','Personal para el control de proveedores y servicios.');
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departamentos_has_permisos`
--

DROP TABLE IF EXISTS `departamentos_has_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departamentos_has_permisos` (
  `departamentos_id` int(11) NOT NULL,
  `permisos_id` int(11) NOT NULL,
  `permiso` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`departamentos_id`,`permisos_id`),
  KEY `fk_departamentos_has_permisos_permisos1_idx` (`permisos_id`),
  KEY `fk_departamentos_has_permisos_departamentos1_idx` (`departamentos_id`),
  CONSTRAINT `fk_departamentos_has_permisos_departamentos1` FOREIGN KEY (`departamentos_id`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_departamentos_has_permisos_permisos1` FOREIGN KEY (`permisos_id`) REFERENCES `permisos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departamentos_has_permisos`
--

LOCK TABLES `departamentos_has_permisos` WRITE;
/*!40000 ALTER TABLE `departamentos_has_permisos` DISABLE KEYS */;
INSERT INTO `departamentos_has_permisos` VALUES (1,1,1),(1,2,1),(1,3,1),(1,4,1),(1,7,1),(1,10,1),(1,11,1),(1,12,1),(1,13,1),(1,15,1),(1,16,1),(1,17,1),(1,18,1),(1,19,0),(1,20,1),(1,22,1),(1,23,1),(1,24,1),(1,25,1),(1,27,1),(1,28,1),(1,29,1),(3,1,0),(3,2,0),(3,3,0),(3,4,0),(3,7,0),(3,10,0),(3,11,0),(3,12,0),(3,13,0),(3,15,0),(3,16,0),(3,17,0),(3,18,0),(3,19,1),(3,20,1),(3,22,0),(3,23,0),(3,24,0),(3,25,0),(3,27,0);
/*!40000 ALTER TABLE `departamentos_has_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagenes`
--

DROP TABLE IF EXISTS `imagenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` longblob,
  `mime` varchar(45) DEFAULT NULL,
  `out_table` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagenes`
--

LOCK TABLES `imagenes` WRITE;
/*!40000 ALTER TABLE `imagenes` DISABLE KEYS */;
INSERT INTO `imagenes` VALUES (328,'/9j/4AAQSkZJRgABAQAAAQABAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2OTApLCBxdWFsaXR5ID0gODAK/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8AAEQgBAAEAAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A8V+OEIt/iLq6BAn74nA+tef17P8AtN6VHYeM5Zo1wZ2LE5rxihdhy3EpRSUtAhyjJrrfDg2hcdzXK24y/wBK6fQTiQfWuTF6wPQwcftHolix8oA1dT5WzWdYklFxV8HFeUnc9uGxYBzTw2OahQ05txXFO5qieKUk+1aMD5FZEeQRxV+GTBxVpiaNONxkVbU5FZYc+lTJI5HBq7isWt2DSO2Tkc0kWWPIqfYMUXJIeuM08NineUPQ0piBFSMj8wkAVNC/zeo9agMJHTNSQRtmhaMJao0oHw4rUMW+EsOuKxEDKc1vac/mQ7T1rrpu5x1EeY+P4DHKGA4as74fW80viO1+yNtmDgj3xXU/Ei32wA45zVf4M6dJceKEl2krGM59K3po86qv3iPpqwi/dpng4GRWvDHgCsyyDBgOcVsKMLXUnoc9fcdRQKKRzhRRRQAUUUUAfJX7XGmrJ9gvUUKy5U8da+YTX2P+0jpL6j4Xe4QlhEMhR618csCCQaSd2zatG1htKKSlxTMSSE4cGt7SJ/LlAx1NYMS7mGK2bABZkzXPXSaPRwSdmelaS4MK881pkZIxWFo5IiB5rfhwcGvGunoezDYkXrVmNd3NMVN1WYY9oqjZDhFnoKkW33EGrEKArmrdvGvensFiKKHp8uasiHA4FTRx89Ksqg2dOaq9yWUkRl7VMuR1qwOTjvSsgBziqFYhxUkaAmnbKcvDUrAJ5WOtSRRAmnb+1RrIwmXjKGiwW0LiwBulaFimyqMUoTAPSr9vMmRg4rop3TOaqro5r4iQGSyUgHvXW/ALS0TQ5b1kG+R8A+mKzvFVr9p0WZlGSgJru/hTaLaeDrEAbTIu8j3Nd9FXZ5eIdndnaQJhxir4FUomwwq6pyK3nocMpczFFFFFQSFFFFABRRRQB5B45jbUvDF5bx43MhwTXwtqtu9rqFxDJ95HIP5194SSRtbFZXUKwxya+O/i/pJ0nxpdoFAjk/eKR0INLZm9RuUb2OHpaMUYpmBb0+MyShQMk12+laOrMski/hXM+F4fNvVHfrXp1pDhFFeZjKj5+VHtYGPuCW8QRcKOK1LVDkVXjiIrTtgqoCxFccY9T0FoW4IckZFXoo15rMfUYYfvuKqza7FHg7h+dVy3K50jovlAGBinLKBxXKDxPDzzj6mmSeI7f73mKPxquUj2qO4jmWpluFxiuFi8S23A85eferUOtJJ9yVSPY0WLUovqdcsi79wb8KnjILZJrl4b9W/iq/b3oIwTTTK9DdZ1HWoHmRW61nNcHqDWbeXpRyd361XNfQGu5tSXYDYBqudREUZ3MM1xmpeIDFkJyRXIanrGq3Z2wAgE00k3a5hOtyrQ9Vm8SRxLlnGaqP4odsGJh1rzPTdI1O5fddzMFz0rrbLSVhQAsTWismczlOWx3Gm+Ky6GK4+aNxtYfWvVPhvrAawhsidyxg7D7V4PBZ/MAvBzXo3wyuGTX1t3PAXArop1eSSRjUoupGTfRHuAkJI21pQH92M9az7VOBWmgwtehVseOOooorIAooooAKKKKAPjK58cXj3BaWPdCW6ZrP8AEmlWXii1WYk+YBw38S+1V7i2AkRQvWphHJaESRZGOoHevBjUqJ7n11ajTenKeR63odxpc7JIpKg4DAdaymGOK92vIbfUbQiRAQ3rXjviHTjYX8keCFB+X6V6eHxHtPdkeFi8J7P3obG78P7Xzbh3x0r0ZIQoHFct8OrbZpxkI5Y12bp8vFcdd81Rs78JG1NEK4Xr0rG1fUWiJSNjmtC5kYKQKwbmEyMWOa5nK2x0SRReaeVvmY0GG4lP3jU2wJ1NTW8yKeWFTzvoRyXM+XSruUfI+3NZt14avhkrLurs4p4tvL0S3cUYPzEit413HYcqMZLU86fRryJhvY/nVm1gvIWBjmYH61qa1rNuHKqMt7VX06Y3J3oCAK3dWo43kjOFOnF2TN3R7u6RlEzE12NjcMVBauZ02PeoOOa6rSYA5AIrljJt3Z0xLnmMw71k6ju+bNddFp4EWetY+sWRC5xitFuE5NI4G52+aecetWbHyg2flzVDxNZ3auDbDg9TXOpc3dt/rAWYUlRe9znlUitz0u2ljzjtWrbKkhwK870vXsgB4yDXVaTfNeSLFGpUt3raMX1IdeD0R1OlRCS6XAyNwrvfCunmPxmNgwAA1c94a0d0jVic85r07w1ZKNS+0sBuEYXNdFKnzNPzMqtXkT80d7bc1eXpWfanitBTkCvQnueILRRRUAFFFFABRRRQB8XtATdIDz3qzcxx7CHIAx1qaKLFyd3YcVl61JiNxXhPS9j7F6szo7uBJpLeGQNisTxNob6iI5I8b14PvVjStOla8DoMbj8xrrLm3CKKdNtO6OarFS0Mjw9afYdNijIwRWkWOCRUEjbMCpYnBFNtXHBJKxG8W8c1VntsDgVsRqDgkU4wqx6Vm1cbszjrrTZZc4JWud1S0vbLDo29T7V6ibZTkEVBc6Uk6YIFXT9zpcmUdDyQ6zdpwVAIqCbVbu4XYDjPpXpc3hGCRiXUc+1OtPCdlCwYRhjXTGUN+XU5nCb0bPNtN0a5vH3MjY9SK7PT9GWCNUVSD34rsItOijUBUAp7QKnIWs68nM1p0UtjOsLIRLW1ppCSKOnNQEgKMUgfaQR2rntbY64RO2tmBiAqtfWodORkdKj0qffCBnJxWvAokDKa1hqxVFaJw99pG9iAMj0xXPXnhmKRs42mvUrmFEHIFZctqkmSBitnGxyOKkecQeEP3gIPFdhoHhxbZ0c4yDxWglu0ZrQtWZSKL22EqEU72Op0NEQKnauw0cmOYqOhFcRpku0Amuy0WUSPkdhXbh3qceLjaNzrrRs4rVj+6KxbQ8itiE/JXZUPJJaKBRWQBRRRQAUUUUAfLni+w/snxRcRYxG7blPThq5DWICkhL/cPevZvi7ov2izt9QjXmP925Hp2NeUBzu+z3Q3xno1eXiKfLNo+lwtb2lJMq6YEXdtx0qxcMGBzUep2UkDLNYdB1X2qrJPvAPTI5HoaxjpoaS3Kdwf3mKltyD9ajnG5uKbAdtR1DobEeAox1qxERnms+GXgZ61ajkGeaZUS4FDL05qVYyVFRxkcelW4cHrUp2Zqo3IWtyadDbqozgVYOGOBTgMDFaJ3E4IqyqM8DFUbnpV+es69ZVXOeaTHaxVyTxinxIWOTVVbjJ4rUs8MBUNFo1dGyp29q6KyIEhB71g2e1CPWtWKUJKpzxWsNNSZq6LV8u4H2rJXIcitvUELaa0sYyy88dxXPW84fBJ681vM5qauy5tGKmVAB71EpyalBHWszRoswS+Xg84rsPCU3myvg/w1w5bIrsPAeWmlPoBXXh37x5+MXuM9DtB0rYh+5WVa8AVqwfdr0Kh4ZKOlFFFZAFFFFABRRRQBzWoWMV7bSW1woaKRdpBHavBfGfhu58P6gY50LWrHMUoHBHpX0RMvzj603UtLtNWsGtr6FZYm6hh0+lGIoqor9Tpw2JdF+R8nzzSKx8smsadpBNluATXuXib4QToXm0G5Dr18mXr+Brz278CeJRIYjpUpYdxjFeXPDzT2PYp4qlNXucmxyu6mocqTVzUdLvdJu2tNSgaCZRkq3pVZUCg4rCUXF6msJKSuhUfjmrMUgOAaqHpRE2OtSaxdjagm7Gr0MmQOaxIpAcEGrcM2DzQ0bxZsI4z1qQuB3rKWapDN8vXkVSGLeTYJ21j38hKZatAt5jZNUtXjzbkqOnNOxnJla3jAGT0IrUtXUYIPFZENwhhGSOlM+3xxk/MPzqG0WtEdpYtvIrQbP4iuO07VxnCtWtBq2OWYH61atYHqdvo8yPatFMR0xg1zF1a/ZryRE+6GyPcVkya5mYLE3foK2IpWmRWfqRWzleNjnStK5NDJnFWA2D7VTjT5iRVhSSKlFTZIxxg9q7f4ejcZ2HTArhZDiOu6+HjBLSYngkgV1Yf40ebi3+7PRrUcCtOCsmzcMBWvDjFejPY8UkooorIAooooAKKKKAMWadd1W4ZVKCuRa/BfGa1LS6+Qc1q30Hax0isCtRSuvNU4rgBBk1FLcDkg0rJDSPL/jxoqz2Vvq8CZkgPlykf3T0P514lj8q+odeji1HTrmzn5SZCpr5lvrd7K8mtpR88TlD+FebjIWd0etgal1ysptw+PWmOMGpX7H0qJjurzpHpRHxPjOTVqOUAdazX+UU+N+3YU+Y0TNFZwe+KkEhPes8PzUyyA1V7Fl+FsnrU0gDxEYB4qjHMqdxU63AYU76idjntU0+VSxgkK57ViNYTqeSSa7e4KuOahNqr4NV7NMybaOUtxcQOAA1bdms0uAxNXns1VuRVm1jABAHNVGnYlydrFnTLCJXDgZY1vL8qYBxWNCzRDNTPeYXPaqeoR0NiJxmpWO08Vgw3+WABq+LncyjPWklYUmXWfcAPevQfCqiHTYyerHNedWimW4VR3Nd/ZSeTGiL0Arswy967PMxsvdUTutPmyFroLV8qK43R5skV1ticgV3vWJ5bL1FFFZCCiiigAooooA8ZW5bzM1r2V4SQM1UNl3FSwQ7DzRdmtjaF6Qo5qKTUcA81UIAXmqdxtIODQ5WLUQvNTAzlv1ryT4iQr/aa3sZGJhtf/eFd7qHfFcl4hgF1YTR5BYDK/UVz1vfjY2oNwnc4MtngGon+WmFtjYPWgv3rypRPajIVhkA03dzxQWzTHYVlZpGlxzPiomuSMgGmuciq8iHJpJ6A5diZLss+1m/Wr0FxhetczeWc8p3JIVPtWfI+pQDaJMit4q+txK53y3CYy7YPvSDV7VOsi155vvpzteVgPrWxY6H5yAyXJU960UX3Nkl1OwXU7eVdwkU4qOfWbWDB3gk+lc7/AMI+u7/j7f8ACrcehWaqPMkd29zVOMmg5UuhuR69aTADeAfeq2oapHHFiPLn/ZqvBp1oF2qmTmriaciJ90Ci1lqc8m27EWl3TTMHOfoa6W1fJBNYFvAI34GK27ZguM8AUR1Ik7LU7bwhZi5ujIR8sYya7OO2BbtXi+k+OG0W8uJEj863PBUHnivV/BPiKz8UWAurMkEcOh6rXoUvdVjyK01OR1+mW+0g11Nj0FZGnRgKK3bdAAMV1X905JqxZooorMzCiiigAooooA4U2/y9KrtDg1tGIYNVJo8GrkrG0XqZNwpEZrHuHKqea6G6T5DWDcx5U1yzep1wWhz19Ieea5u7J8w5rotRjIJrmr47d2enWs7ia1OG1qAwXcgA6nIrOaVlHNOl16DVNWu7WPrAcA/3qjl689K4Ky5JWPQpS5o8yFaXA60wvu560yUYXK8g1CkgXiuepdM3hK5ZAPapFIZsHtUcbhmqwic5FQmaXHqinoKhmt1fqBmrSrkcVPHFkVq1cb2OcntChyFyKfFdPGNrRk1062YYdqcNOjB5ANVGEuhSk0rHMG+mZ8RxNVm3+1TEBkIrpEs48/dH5Vat7dAThcVpyvqwcn0KGnWuwBn61pMm4e1WooFA4pXj2dq0ZkzNaHHIrI8RauthaeUGAmk4HPStHXdSg02xeacgAdPevF9X1qXUtUM5JxnCj2rWjTcndHn4vEKK5UdZDdqkLl+nY11Pwj8VjQPEMbSN/ok58uQZ/WvKLzUGESwq3BOTV/TLgDbXSm92eNz2dz9C9L2SRJJGwKOAVI9K3IwAK8R/Z+8cx6vpSaNfS4vrYDYW/jSvbo+mK6b3WhpUd9R9FFFIzCiiigAooooA5wkAGq0nzVYHeoJOtaSNY7lW5jyh4rDuY+vFdFIcrzWXcqDkYrkqbnbT2OR1KEnPFcP4s/0TR724OR5cTH9K9PvIuoxXn3xQtWPgzVii8iEmoQSPmHw9fm11yOd2wsjENn0NelzbSMjoa8dBINeqaBdC90e2lJy23a31FZY2nopDy+pq4se744qpMQeVq7cxdwKouhrytnY9JaDEkKuOa1ba4BXrzWJKGAqJLlkPPFWo31KuzroJQx+lXI3GB2rkrbVAvBataG+R0HzVTdnqaRmrHQRvkZFWIZF/irChuwo4bip1uwR1q1Iq6ZtGUZ4pfNGOtYwu/U0xtQUA5YVV0wukdHBONp+aluLtFjYswCgZJrkpdaRD98AD3rjfFfi154mtLJvkPDv6/StaUHN2Rx18RGmmzL8b69Jq+puqMfs0Z2oPX3rm8/nSMc0leokoqyPAnJzd2O3c5NXLGcrJ8xNUaejbWBokrqxDPRvCeuXGl39veWcrRzxMGUg4/Cvtr4Y+MrXxj4eiu4mUXKALPHnlWr8+tPuTxgjivUPhP43ufCHiOK6Uk2khCTx54ZfX6is6cre6wufcoOaWqVhfwX1nDc27boZVDofUGrasGHWtR2HUUUUAFFJmlzQBzDNjikT5jTnXJqNM5Nas1iyK5IUVQlxVi761m3JIxXHUO2nsRyoGasjX9KS/0e9tnGRLCy/mK1EQtIKZq08NhYzXN04SGJCzMalBOx8DX0JtbyeA9Y3K/ka6/wCHt4Ck9ox54df61zviq4hu/EWoz2pzBJMzIfYmo9BvTYalDN/DnDfStK0PaU2jloz9nUTPVJVyvFUpEHfrVtJllQOmCpGRTJFyM14MldnvqxSMWe1VJ4Bg5FaLMFFVpCD1qU2mJGLc2ZPzI2DUAN1CQFYmtpwD2qjeXENqpaRhn0rqhOUtLXBzUVdkK3d2nJGahm8QSQnBwT9ax9Q1eSclYsolZTMT1OTXfDC3V5o4K+PS0po6STxTOQdi4/GqM+v3co+9t+lY9JW0cPTjsjhli6supanvZ5s+ZIx/GqxOaSitUktjncnLVi0lFFMQUtJRQBcsZAvB4roLO42gZauUzVuzujEwDcrWU6bfvIlrqfWHwL+JkNrZx6JrMm1QwEEpPAHoa+h4JwyhlIIIyCD1Ffndp16VjJVsc8c19C/Cr4zJbxWuleIATGuES4B6fWtIVb6MuLufTKvkUNKFHNZ9rfQXFsk9vKskTjKspyDVK71FEyNw/OtOVDsasl2o6VXkvD2Nc7Jqi7vvD86BqKMeoo0Goo1jHjmmBOTWjJEDUAhOTVjTMidOprOuwABmtu8iKisDVHCJn0rGcTWMmiNZAGHavBv2lPHHlQx+HdPk+dxuuCp6Dstel+MPEkOgaJdX8zYEa/KM9T2FfGWu6nPrGq3F9duWmmcsc9vapUUKpU0KLHmgHFNoqjnOo8P66YAsNy3yfwn0rsIZ1mh3K4IPSvKQa1NL1iexYANuj/umuDE4JT96G56GHxnKuWR3E0hFVJrkLkk8UxdQiurfehB45x2rnNU1HLMiVx0sPKT5WjulXio81y7f6x5eREea5y6uZLhy0jEmo2YsSSTTK9anRjT2PKr4mVX0FzSUUVqcwtJRRQAUUUUAFFFFABRRRQAUuaSigCxDcvGu0HitGx1EiXMjYHasegHFS4JisfQHwy+J99oMa2czmewP8BPK+4rv9S+IkMiiSKTKsOnpXy5pN+QVVjgiuusr3zY9ucmpU2vdZSfQ9e/4T9S/3+Pc1qWPjaGQj94PzrxORdy/KTn0qAPNC+QWqedo0S7H6CBRioDgOamPFUNSuoLOFpp5FjRRkljiulMlblLVp1jRs9a8z8XeILeytXknmVFXksTiuX+Knxu0nSzJaaURfXY4yjfKv418y+KfF+reJJ2e/uG8vtEpwoqJNspzS2Oo+LHjweI2jsbBj9jibczf3zXmpoJpKSRm23uFLSUoFMQCrNtZ3NyrG3gkkC9Sq5xXV+DPB0mqOLi+VktRyF6F/wD61esaPbWmjKVtrWIQMMOmOGH+NBcYX3PnyQXFoxVxJET2IxVdiWbJya9n+JPhRb7S/wC0dLHmRxZbGPmUd1P+NeMHg0WCV9hKSiiggKKKKACiiigAooooAKKKKACiiigAooooAKKKKAHqxU5Bwa29J1EK4DHDVhUDg8UpRUkB6FDc7gGB5q7FcI/yviuM0rUyB5Ux+hrUW5O/jmsZaaMcZNH118Sfjt4e8Lq8FjKL6+HGyM5APua+WviD8WvEfjGR1uLlrazJOIYmI49688d2dizEsx6kmm1uFxSSetNoooEFFFFABXQeCNOt9U8RW1veEi3JyxHbFc/XSeApxB4kt933XBWga3Pcbi0fT0WFk2pgbGXlWHbFVss7VpafqCeQLW+Uy2x6c/MnuDUt7pTW6CaFhPat92VR/P0NCVzcp2lxJYs0kZBDDDI3Rx6GvHfiZpNnZaqLrTU8u3ucsYv7jdwPavXL1xHC27HFeZeP5I5bLOfmB4ptWM5HnhpKWtfQNDn1qdkgKoiYLu3QUjMx6K6PxP4WutCSOZ3Sa3kOBIoxg+hFc5QAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUALnnir1releJCSB0NUKXmlKKktQEooopgFFFFABRRRQAVq+Fs/8ACQWGP+eorLro/AFvFceJrU3HKRnzMepHaga3PabYqSORWxYXsliSYyHib78TfdYVRFtZXoLtGInPUKelZl9oT4P2S6kX2zTWhsx3jJ4RbNc6cxMZ5eInmM/1FeG63qUl7OVJ+RT0r0PxTp+p2el3F0LhgsQ5b19q8qdizFmPJ5ND1dzKW4ldT4G16DR7ieO8U+ROAN46qR0NcrS0iTt/HHiSDUbNLSzlaZCwd3IwAQMYFcPS0lABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAf/2Q==','image/jpeg','administradores'),(329,'/9j/4AAQSkZJRgABAQAAAQABAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2OTApLCBxdWFsaXR5ID0gODAK/9sAQwAGBAUGBQQGBgUGBwcGCAoQCgoJCQoUDg8MEBcUGBgXFBYWGh0lHxobIxwWFiAsICMmJykqKRkfLTAtKDAlKCko/9sAQwEHBwcKCAoTCgoTKBoWGigoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgo/8AAEQgBAAEAAwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A8FUVIFoUU8Cuw8sAKkVaFWtbw5pbatrFrZLnEr/MR2UcsfyzQB3fgTTRpXh99QlXFzejCZ6rEP8AE8/lWlqe4WkFsoJklPmMB1Oegq7flJ7+3s4QFhXCgDoqL/8AWFXfCtr/AGr4r891/c2373H04Ufng/hWTfU64x6Hf+GtKXSdHtrJQN4G6Uju56/4fhXl3xKurjxN4nnsreRY9M0pP30zZ2Ie5OOpz8oHUmvVdVvjY6Zc3KLvkVcRp/ec8KPxJArltf06w8O+GbC2vZbCIzN588lxE8zzT4+ZhGCA3XjccDjisVPlfmzWVPnVr2SPDUjqdY6v6neT6jfPcXMzTMThWZQvy544HA+lQBK7keW2r6EapTwpqVU9qkWOmTcgCU4R1ZWOpBFQIqiOk8uroio8qgCiY6jaOtuy077S2XYRxDqx7+wrpLTTLJY9qRI3qWGSaznVUTenh5VNdkedtHUTR16G2j6c92I7qLZE/wDHHwVHc4HXHX86yPGXhS58N3SiU+ZbyEiOQevp+XOe9EKsZOwqmHnTV90cc0dRshFX2So2jrUwKJWmMlXWjqJkoHcpslROhFXGSo2XFILlIrTGWrbx5qF1x1pWKTKrLTCtWWWomWpsaJlcimMtTsKjIoKGgVIopqip41oEKiV6L8MLERW9/qbjkAW8Z+vLf0rgUWvWbCL+y/BVlEOHeLzm+rnI/QilLRFUtZXFsH3fb7w9APKQ/X/6wrtvh/Z/Z9He5YfPcuT/AMBHA/XNcVHE0ejWsKD95OxfHrk4H6CvVLOBbSzt7dfuxIF/IVzzfQ7YLqc14715NJu9Gjdd6faVmlX1Vf8A65B/Csb4x6VdTXlrrkEjXGlzRqisCSI269OwP+ffnPiJeG98UTqDlIFEQ/mf1NehfCbUYdZ8PXeg6qomhVdoVu6H/A96Ul7Llqff8yIy9u50X8vkeNKlSoldF4w8NT+GtaktJMvA3zwS4++n+I6GshI67E1JXR50ouLcWRLHUqx1MsdTLHTJIFjp4jqysdSLFQBVEftVuxs/McFlLDOFUfxGnrEWIAHJrbLrpcC+WA10y4X/AGF9fqeazqS5Vob0KanK72Q2/wBMb7CwKKrqMgL2rN0edlcxueRWlEb3yjJK21X4Abqf8KzUCx6g+OwGfrXJJ6npxWhpTENeQD/eJ+m016F470R9Q+GEbGMvdW1nDMfUFFG4/wDfO6uL8H6cda1za4/0dCBIf9nqR9TwPxr2bxRdRWPhTVLmfAjW2dQD3JGAPxJApJ2krCmk4tM+S2jqJkrReKoXj9q9A8UoslRMlXWSo2SmBRZKhdKvslQutAFBlqN1zmrjpULrQO5RdMVEy1ddciq7rg1JSZVZcVGwqywqFhUs0TGotWY1pka1ZjWmhNk9nbmeeKJfvOwUfUnFereLCEEVvEPlBCKPYDFcF4Sg83xFpqnp56N+Rz/Su/1NftGvWaHp5gJ+mf8A61RUNqHVmjZW4k8R6fbDlIcf+ODP8xXeTuEjdicACuP8Lr5viC5mPRIzj6kj/wCvW54kuPI0O9kBwRE2PrjFc0tZWOyOkbni1/cCa8uLmVgvmyM+SfU5ra8F6x/ZGrxXcb5iPyvj0ry3xfeXH2wJG/lorbVJbA7ZP61o/wCi2mm2N3Y63LezxrvniRgCrEgbQDy3X+tVUrRd4NaGdDCT0qp67n014mk07xh4SnjtpoZtUtF8+JFbLY7j8Rnj1xXkNpbSXEyQwoWkc4UDuap+Bddmi1GNTbzSyTneke8KCgYg8bsZ+fpzg/iK6mC6+xGUsEW5dmaV1HTJ+4PQAcHHU57VnRrOCcTXFYVVJKadu50Oi+EtJRM6pcTzz944PlUfieT+n0rWk8F6FcKfIkvLZu2WDD+X9a5rTtVmeKSaMbYY/wCLuT6Cuu8KLca1pUl+ZhFAjFT6im6s73uCoUkrWOYvvCAgJ+zajBIB2kUof61kS6VcQkhlVh6qwNdvqE2moXaSeWZ17LjJqraw2+pTLDZ21xJK3RQBmqVeaM5YOm9tDk7SFUukM2EVTkluK0dOijune7lIbc3A9AOgro7nwnPH809uiHsHbd/LNRf8I1ezfKZo4YvYZP5UpVHIunRjTVkzl9c1JIVKxfPN0HotYVjFPPMkMSs88zYHc5NemQ+ENKtlMt/I0mOrSOEX/P41Dda/4b8NRtJaWwvbkDASMbI/+BOeW/UVBpc6jwXokGlWsMYI2M33zwZ3zyR7Vznxr1O7N7baSuEsxGLggHl2JYDPsMdKd8ONV1Xxb4kk1K9wlnbDIRBhAeiqPpyfwNZnxPuVv/FMwQ5W3RYM+4yT+pI/CtKK9/U58XK1M85kiqvJFWzLD7VUki9q7TyzKeOoHTFackdVpEoAz2SoWWrzpUDpTApOtQSJV51qB1oAoMtQuuauSLUDrQFyi64NROtW5VyM1XYVLLTHRrVuFagiXmr0K0DOh8DID4msc9mY/wDjprtAu7xHET/CjN+jVyHgn5fEtifdh/44a7YJjWyfSFv61nU3OmhsbHg5f9I1B/dAP1rjPij44X7R/wAI9o7qZ3Gbi4I3LEoPIHqeP6demw17NaaPeQ2bOt3eTrbxsg+ZMglmHuADj3xXjGvwGPx3q1orhcp5EBDcDaoAGfXj8645uzZ304ppJm9pHw8ufHniB4Yb4WthDGu+eb5nY4BOAO/PtV/xp8B9V8L6NJqukapFqCQctHt2uB6gcg/SuJ8KeMdR8MXk6ebJiNzlQeR2717do0doNEmvbbXX1ix1iLLx3JCyWyDqrjOc5Y/N7DFc8pSW52whCVrHl3w9WZ9Xtb3Une11Bplkt/3ePMAPz85AUYz2Oc4xzXWXkxORk5J5qjofhm40jxaCLgywSyAxyHG4pnlTS3cmHB9GrWm1JXRhWTi7M7u0iVNIjQdNta3gS/aPwprdnu/1dwrfgQf8K5+yug2nqM9BUvg6fNxrkGeHjST8mx/7NWkloYp6lW6kkM2VBeRm2ouepP8An8q9D0G+bwtoyR28H2nVrpBJLM6nainlQB9Oce4zmuU0mx+1aizDqGWCP/fcgf1H5mvStShWOeQsyRxg4UdcKOB+lKLs9gmm1ZOxytxqurXrM1xNKSemF2gfgK3JtZt7O2aPT7EyzbdomujwDjrtzz+lV5JYGfYkjux7IhzUJsXnPy21449ozTbb6ERioq17nGXNusTtLNLLc3DHJeRixz/T8Kj0zwle6/eL5oMNtn5mbjiuxhSyiYMsG5vUjNWpNVmVNtuojx0OOlNQkyZVoR6mtcXFl4P0FLDS1X7SV+UY5yf42/pXmdxEzuzuSzMcknqTW7OrySM8rF3bksTkmqksPtXTCKgjgq1HUd2c/LB7VSlhroZofas+eHHatEzBowZYqqyR1szRVRljqhGTIntVd1xWnLHVOVKAKDrUDrV11qs4piKci1WcYNXnFVZVoAqOOarSLg1ccVXlHFJlIfAtX4RVWEdKuxCgq5teFW8vxBp7H/nsq/mcf1r0SWPbqyn+9GwrzGxkMFzDMOsbh/yOa9avYx9st5V5UsRn2IrKrudGHejRz2oajb6Hpd1q11byTx2M6vsjHzHcrKPbqRyf/rV41rctxPerrdyrxCd/MZtuRGzMx2nvkEdMcjmvcNQ046jpuuaeImlee3DogIBZlPHX3xXlmraHqEwurfWFt7C7tETbDGrM0wJJ8wYyG6kFug4H045puVj06Uko3Zx2r6na7opJAsl6vPmRrt3L6HI5/KpNN1C4SA36xGKOJgylHI5zxj8efwqPTtEXUPEEdi8vmhcMzLwGXqwB9s17L4V+HFrqMTRyRAWKMDuZR067QTyec/n+FL2fu3lsN4h8yjHVso/Dq41PXL2DV9ScWelwkQRF13GZs9sD14zWdqWV3A9Q3NbXjq9j8OzaJoOiW8i2kV1FmXz3dR84yMEbfwHT2rG175b28X0lYfrThy8vukz5+Z87NPSLzNuVJ7VreDJv+J9fL/ftD+joa5HS5SMiuk8FN/xUj+9s4/lWkloZp6novhdFS408kfeu2lPvs3N/JBU8k09y5eeV3Y9cmjQYyfsm3gpDO35xuP8A2apfJePG9SueRkdadHqc+MbuifwzJ5Hiq1U/xoQPrzXo9rJvaVM8o1eVXMpsb2xvRwIpRuPt/wDqzXe/axa+IkBI8i9iDo3YsOCPy2n86moveNaDvBHK31r5F7PFj7jkD6ZquY/auk8VWvl3qzqPllHP1H/1sViFa2jK6ucVSHLJoovHVeWKrV5N5SnYu5q4vXxe3YZWlcIf4FOBQ5pFQw8pal7UdU06zJFzeQIw6ruyfyHNc/deK9GBIW4d/wDdjb+ormNQ0l1JNYs9kyHmpdV9DdYSPVnZnxJpkpwskgz6oasxlLsZtzvH5VxGnWQeYF5EA9zXo3huxiymJIz/AMCFL28kP6nBmTcwPGcSIyn/AGhiqEqV7po+jw3duIp445oz1VgGFYvi/wCGRED3eg7i6jLWrHOf9w+vsfz7VpCupaPQ56mElHWOp4zKlVZBWlcxsjMrqVZTggjBBqlItbnIUnFVpVq661XkFMRRcVXkFW5BzVeQUDRJEKuxCqkVXYRQMsxivWdKk+2+HbKccusYB/3lOP6V5ZZwSXE8cMCF5XO1VHUmvTdEWLwzpUkGv3tvB8+/aHzsyOhPQHj1rCtOMVqzqwlOc5e6i7a/uNdt3/hkBjP48j9a2NW0OHVVIkREkaMxGV+gUkE8d+lcpffELR7KFhoNvNql7jAaJMqv1foK4fxLrviDVbVZ9S1NbSFxlbe16/i3r9K4uaU3eCPT5IQjabO6vW8EeCoyl0xu7nGDuYuxx2x0/rWXd/EPUtQiEHh3Q2igIwsk/wAigf59K5zQtMsFgiu4oRJNIA5llJd89+T0/Cugi61usK5a1Hc5JY5Q0pRsYE3hi+1zULW71rVpHuIpkkSKJf3SYYHGD1+vFZviM/8AE3vx/wBNn/8AQjXoGnrm6hH+0K8/1seZql646GZz/wCPGrlTjDSJNGtOpeU2VLI4IrqPBBzr8rf3bd/5gf1rl7YYNdR4KG2+vpfS3x+br/hUyWhsnqereGZQgMh422z4+pZf/r13Ea29zbFJxuj6EEdPceleb6HJusQC20NtTP13f4Cut0XVoJLa+uHkVYIZmh3McD5QAf1zWcVoE3rZmVrumusM1uwJJGY27N6EVJpdy2teEAsZP9o6UwdfUqP8RkfUV0dm9vrVkfLkWSIk+XIvO01w80s/hHxStyUP2eU4lQdGU9cfzFXL3l5mdP3HbozurG5j8QaDhSPPQZweoI/ziuXu3MXydHJwfap5ZP8AhH9aivbE+Zpl4PMTb93B6j/PtVbULtb++muRGI1Y/Kv+e9TBtKxdSmpSUipMRtrmNe1K3s0YysM+lO8XeI4tMjMMRD3BHQdvrXlOpXdzfTNJMxJNCjctysXtY8QNM7CFQornprmWU5ZqWSNqgKHNVaKF7zFBOeWxV2zvZ7ZgYbgrVJY/WtvRtOWVgWUH60c0ewuSXc6fw9401iydSjeYB9RXq/hn4pxTbItXgeM9N45rifDmkxEqDGv5V6FYeErK8iCyQrz7Vm3F9C1GS6nPfFXRbHULUeJdCeOSMkLdrH2J4DkdvQ/h715NKtew6/4W1HwwXvNNPnWTArNC43KynqGHcV5lrtpFDMs1oGFrNkorHJQjqhPcjI+oIPeuqjK6scGJp2fMjAkFV3Wrsi1Wda3OQoyrVaQVekWq0i0AMhq9DVGKriOEXJDH2UZNGw7X0RtaHqUGj3n9oXMvlRW6FidueeAPw5rT1i4sNS8VvqUsMN5CzKVEg8xMbQMgHj3rhIlfVpbrzVMUPktDGM7hzkFv511BMfmt5O7y8/LuABx+FcsIc83NnfVqeypRpReq3/M6O5kN0wS2QbF/gUYGPauf13SHEJCEsjfPH/UV0/gsJNehGxuHOPUV1Ov6EtxCzQLz1KjsfUU5e67DpvnVzy/wjMfs0lq/DRNlf90//Xz+ddNHWYdMe1vhIibZBwy/3h7VqR9q1hK6OSvDllfuaWl4Fyrt91AWNefEecskh/jYmu3v5fsOiXk7cN5ZA+p4H6muGjkC2oHtWc3dnTQjyx1KyDDGul8OHybG8lPBYqo9+uf6Vzic5NbqyfZ9IjXuxL/nx/Solsax3NvW9QNr4XswrlDPdRpuzjbtw2fwwaxI087T7/UInk3PdSSIhJxtySRj8c/hWZ471WIafoWnFiDLLubH+f8AbH5V33hrSHbwxJCgyJ/lG7tz/hV09ImVW7keh/C9ZIfDNt5oIZstj61peMrGDWNIuFUhbmBgFb3wCP5/qar6BdR2tqls3yvGoGK4zw9rV3qeq3ckryLbTzPIiEYGBwPrwAKhq7bHzWhYTQNZkTTp9EvYiwVw0JPWFgfmH06/mfWna3fGytSIBunf5Y19/Wruoaai6ol8hCllKuvqex/z7VElos1wZ5RkjhR6Cpasawlzq5wY8Py3DtPeMWkY5Oao3+lRwjAUV2HirW7PSYyjMGmPRB1rgT/bHiGZhbW8wiJ5Ea/zPQUldltqJlX0cEJPmSqD6Dk1SjgmuTi0tZXB/iIwPzrtrHwBqHDSC2tz3MjeY/6cfrWovgmRB+91WU+yR7f61agZSxEV1OK0/wAI6teOMC2hz/z0k/wBrr9M+GetSqCur2sX+5uP9BVg+FVj5XUbsH1zRHa6xp7brHWrnI6K7HH5EkfpT9nLoR7eD3uPvPBXiPRnjZtakETHHmK7hV+tR23iPxfokxWLVHcxnDRzIsg47cjP5V23hHxoLpho/ixEVpvkSYgBWP1HANZnj3QJNLuN6/NEANr/AN5Og/EdPyojvyzQVH7vPTZ0HgX4nrrs/wDZXiS0ghncbRLGTsb6qen1BP4VyHxE0H+x9RvLRB/o8g+025+mcj8t35CuQubd3kE1sxS6i/eRsvUkc16Zqmox+KvhzpmsED7TZSCC5A7A8H8Dx+dNx5JJoUZ+1g09zxyVarSDir1xGUdlbqpINVXFdBwlN1qtIOauyCqsg5pgilEeKuwnis+I1chNAmW7dEjzsGAccDoOMcVeiNUozVqI0WsDbe5raddS2lzHPA22RDkGvWND1aDVrMSxELKOJI88qf8AD3rx6E1p6ddzWc6zW0hjkHcd/Y+tROHMa0qrpvyPUb3T7e55eNSfXFUW0m3iJkYAfzNZdv4xhEQ+3wyI3d4huX8uo/WsrXPHdpHEw0+OWecj5WkG1F9z3P0rDlaO1TjJXRlfEfUFQQ6dERuJ82UDsP4R/X8BXFo5IAptzPLdXEk87mSaRtzse5qW3TuadguWYVyyKOpNT6neKzRwRsOSEH06VRafYWYHkDArGaSeRru8VWMNqnLdgScChq407FHxDcDU/F8UaMfJs03Mc9Mc/wDxIr3fw9q8v2bQtKsyvmiNZrlyM7R1x9TXzRZzSebNNu5mk5PqByf1P6V698J9RludSu7iSRViUAF3OCfYUvIbV9T6BnWNoDcLgHHNZunXek3mnRW9lNCs9sxKx5598e1VdXv1TwlLJG/M7bEOfbk/zrnPBOko8cepGUMhJ2KvsSDn8qSRnJ2R1Go8ui9hya5vxXr66Lp4EfzXk3yxIOSPfFbmq3McEc08zBYolLMfQAV5/o9o3iXWWv70sglLJbr12AA8/pj8/Wk9WXD3YFvwP4e0/WbiZ9YuGbXHbdBDKR5Tj+6D3f68V6fpk8FzarpN8iWlxB8kD7doX/ZYeleQ39vNZXLwTgpIh4I/Qiuj07xalykdv4h3l0G2O/jGXA7CQfxj36/WlJO90UnGSszq76CW1neGdCkinBBrPlNbUF2l3YRR37rcWv3YL6A7wvtn/wBlOCPaszUrKW0IZiskLfclTlW/wPsea0hNS0OSrRcNehlzVRnq7LVGatUcxm30KTxNHIAQf0rq/Bur/wBvaXL4a1hvMvYULWcrHmRccpn1x/niuYnrLuHltrmG7tXMdxC4dHHYjpSnHmRrRqcsrdGOu4ZNP1JopMhonx6ZHr+Ira8BS7G8S6Ex/dXVsbmFewZRu/wH4VJ4weLV7Cx1+1UKLgeXcIP4JB1H55/MVh6Beiz8WaPdscIzmCT3Gc/+zfpUt80bmsFyTa/qzMLU123k3uxP581nvW34mgNtrFzE3VG2n8OP6VivWq2OaStJlaTFVpBVqSqzimIyYTwKtxHmqEB6VciPNMGX4zVqI9KpRHircZoJL8Jq7Eaz4TVyI0AXkwQQeRVG90gTAtBjP901biNXIj0pNXHGbjscZcWrWr4mRlPuOtVpbjAwvAr0Xy45kKSorqezDNV/+Ef02RstBj2BwKhwOhV11OBsbO61W6W1s0JdurHog9Sa7zxF4YA+H91pWlLunCiTp80rAgn8Tg4/AVuadaW9lH5drCkSnrtHX6nvWjG2KOWxEq3M9D5v8OaBdagJfs6GR4RvMX8TDvitWxvTp7tFarLFKpyVPIP1FexatPo3hlrjW7mNVkdShjTGZHPOcevFePeIfHttrt7FCdLt7JV/dpdhsyLxgbjgAjpniueo0j0KHNNLTQ6a+8cajf6SkF7JGioPJijjXaBnqfrxXpHwtud3hcRE8wyMMex5/wAa+bUllOuIt0zBkbBB7Gvb/h5qK2cF5vY+SVD9MZI4x+tYRqPnR01aKdJpG344mm1G9sdAs2IkunDzsP4UB/yfw96t+HkSPVoooRtihQhR6DGBUWhQN5l7rV1/r5QQmf4R7fhipvDClry4lPRRj/P61tu0jml7sGzZ17TItUt8HCTr9yT09j7V5vqFvPZTtDcIVcdj0PuK9TLVQ1Oxt9Qh8u5Td/dYcFfoa2scMKvLueeaZqd5pkxl065eFjwyg5Vx6Mp4YexrtdE8dQEGHVIPI38M8K74n/3oz0+oP0Fcrq/hy6tCz24M8Xqo+YfUf4ViB2U7WH4GpcEzqjUutD2KXTYNRtjdaPNFLH3VH3L9ATyD/stg/WucukeORkkVkdTgqwwQa47TdQuLC4WexuJbeYfxI2Pw9x7V21n4vs9VhW28TW22QDal/bLhl/3k6EfTHsKcZOO5lUoqWsdGZU1Z9woYEHoa39V017WJLiKWO6sZDiO5hOUb2P8AdPseawpu9bp32ONpxdmSeHLkE3mj3DAQ3y/IT0Wdfun8elc9dO0XzYIeGVZB7Y4P9KnvQRIGQlW6gjsR0qrcXP2555CAHcEuP9rqf15rO1mdSfMkza8dYfWvPXpcQpP/AN9DNcs9b2tS/adJ0Wc8kW5hY+6Mf6EVgPVR2ManxMgkNV3NTyVXc1RBhQmrkZ6VnxGrsR4oGX4W4q3GazomxVyNqZBoRN0q5E1ZkTVciemDNOJquRNWZE/NXInA+8do7nBOPy5oJ30NKJq1rSCMW4uL2dba3J2q7/xH2qHRpfDDRR3NzrUMiZ2lOUIb0II3Y9+K5z4g6zbatqFrD4eiF3FCpQqYmKr3BUHiuKrib+7T3PUw+AafNX27HXQeRJIRHdwMgON27H6VmeLvE+n6BZtDbBrq+cYDbhhfwFcvBpmo6laxi6gtrOXo0oGXI9h0FbOneGNOtgpkQzyd2eotXqLXRfcaN4Og7rV/eeQXOmaxrNy0s5cxuxb5m6571cs/AEs7ZWOaQ/3VXP617hb2drFjZbxj325rmfFvi82iPZaLh7r7rTAZWL6ep/QU/qz+0w/tBSdqcb+p5frOkS2OrRwSqEuAijrkrgcZ98Yr0XwNDdapaj7XgMjgSAH72Oh/GvPWguZDLKrtJcqTIxY5JPfn1rt/hd4itTqKw3ZEUj/I3Nc1RezkehSftqfmz0XWrhYLRLePvxgf59auaTCbSzVSB5jfM/19KpnT5V1iWS6wYoj+59H9G+n9fpWjn3rupxuuY8TFVXf2fYnMh9aYz+9R596QmtbHHcUmszVNLtr8ZkXbL2kUc/j61fJqNjTtcFJrVHDajpM9mxJG6Ps69P8A61U1Zk4PSu+lwwIIyD1BrC1DSVYl7f5fVD0/Cpcex008QnpIo6Tq11p0jNaSYRxiSJxuSQejKeDWs0unamu6Bl0+67wysTEx/wBl+q/RuP8AarnZbd4mw6lTSByv3hkVKutjaSjNWkWdSt3jyrlCwGcq4YfmCayI1CXDMOjnJrQ86NUYnJOCAKotwgPvVXvuQoqKsiXcW0byyf8Aj3uDj6Ov/wBh+tZj1oQnL3Mf/PWIkfVfm/kCPxrOkq0YT3K8hqu55qeSq79aolHPRGrcLVRjNWY2qUUy+h5q1E1UY2qeNqolmhG1WonrPjarMbUyTUiercT1lxSVbieglov/AGe3lkWSSCJ3HRmUEitC3CIMIqqPQDFZsT1bielZbhzNqzZpxtU5mSKMvIwVR1JqlBufOwE46097QlWuL11it4xks5wBUykomtOjKp6FK9urnUQYbbdFAeC3RmH9BXDa7JDaTm2s8O44Zx0X2HvWxrviE3JNppQMVueGl6M/09B+tc/dRLDgsOaw5nJnfGnGmrI1fCEUSXDecA24YIPeue8VaFcaZqI1HTFk+yNIQkgHAYds11/g3RJr5xd3G6Kz/h7GX6eg9/y9a9CmtbeezNrLEjW5Xb5eOMUTo86IjjfYyste5nfDrxKnibQhBKw/tC1GCvdhXQ5rx3WNJ1HwTr6avpBdrXfk4/kf8816to2q2niHS11HTWBGP30Q6xN349Kyw83Tfs5/I0x1JVorEUte/wDn/mXM0hNM3Uhau08gcWqNjSFhTCaAEc1XkqV2qvIaYipcxrIpDjIrGurR0OYjuX0NbUpqnMaTSZrGbjsYTnBwykGq8z7sADAFa06huoBqlJGg7H8KXLY1VVPcrwSCK6t5H+4rjd9M8/pVS4UxyOjdVJBqxOo7Zx71Wl5znrTsTJ3KslV361Zeqz9aZJzKVYjNV0FWYwaktlmM1OpqCMYqdBVCZPG1WUaqsamrKA0EFmNquRPVGMGrUQNMRoRPXS6Jo7XMa3F5J5Ft2/vP9BWBo1ubi/gj2FwWyR6iu11O9tdFgFxqU4EpGI415b/gI/rWVSfLojfD0VP3nsSajdWel2+yGA7gMhAfmPuT2ryzxNrs2pT7XkDIp+WNPuL/AIn3qPxJ4jn1SVkQeTbZ/wBWpyW/3j3rHt4jKck7U7msVG+rO5yUdIlmwGJN2NzfoK6vR/DiXkyXeogmIcrEf4/c+3t3/nf+GulWU9/9ovow6oN9vFIMrKR1J9cdh35Pau9u9PsriQtYyCGXvC54/A01OKdmZVKdRxvEyI8AAAAAcADtUoNOe1lhbbIpBpViPpXRdPY8xpp2Y2WNJomimRXjcYZWGQRXmkss/gTxIW0t3FtNIODyMHHyn1616iIm9KztX0WG/AkkTMqYIPuOn41z4mnzx03R3YDEexqWk9GbEpiu7OG/tYzHFMPmjP8AA3p9KqmsHweZ4NUlsbiaQwyfKB2HocV0slu8bsjDlTg1OFq88bPdFZjh1Sqc0Vo/zK5NMapzC3pTTCfSuo84qtUL1caE+lQvA3pTGUJKpzDitOSBvSqssDelA7mTKKqyitSW3b0qrJbt6UwMmVc1VkWtaS3b0qtJbN6UFJmVItVnWtWS3b0qs9u3pSKOTjQVZjQVnJOPWp0ucd6AaZpxoKsoi1kpeD1qZb0etArM10QVOiLWMt+B3qRdRHrTA3o0Wr9jbfaJkijxuauYXUh61t+GdRDXcpByViJH5ik3ZBGHNJJnV3Gp2/h+zZLJVNyRhpmGcH29a841fUJry5kmuJWd2PLMck1JrmrefO4jbdjjf2/CsLeXf5jWCj1Z3uSS5YluKPcjSvxGP1PpVvRQt9rNhZytshuLiOFiDjCswB/Q0t+n+gReV90DnFYyyMjhlYqynIIOCD60r3Hax9Gax4diMhn0QLGV/wCXbO0DH9w9vpXO3F6/mGK8DxXC8HcMGqXh3xwur20cc0qwasoAIJwsx9V9/atK58SWtwv2fW7QSAcbsYYe4Nc3K0dakmiodWvbcY3+bH2Dc/rU1v4lKMPOi49G/oarPp1vdAyaHfpKOvkSn5h/X/PWsmaV7STy76Bo+3I4P401JrYUqcZr3lc7yw1rT7ohfMEUh/hk4z9D0rWCp7V5jHFbXIzBKFY/w5rQsby90/CrIXiH8Lcj8PSto1e5x1MH1gXdf8PXkeprqOkyyyAtukh8zB/DPb2rr7cbraEyqVk2DcpOSD7nvXNQ6xLNxGhL/wB0ck/T1qL/AISBQcFsGqp0YqXPEyr4iq4KlUWx1u1PamlE9q5Ua+p/ipf7dX+9W/KzjudMyJUTontXPf22D/FTDrIPeizA3XjT2qtJEntWO2r571E2q5707CNOWJPaqskSVQbUs96hbUM96qwi3JCvpVeSFeeKga9z3qNrvNAWY6SBaryQLTmuM1E02aBo8mERp4jNXdgpdgFHIi/aMphD704IferWBQdoo5R+0ZXCGlCmpi6CmGVKOUPaCBTVq0meAvsYqJEKNj0NVPOTsKcs4z0o5QVSzuOkyvWod2DkVaWdDwwp3l28n+yfY1DgzZVl1FtdRaNdkg3JSTJDN80LBT6Go2sUb/VzY+oqCSxuF5Rkf6Gs3TZtGtF6XEkV4zyK0bfxDdJGIro/aYhwN5+YfRv8ax5DdRffifH0yKrm6jJw4wahruaxd9YnRjUUZg9tM0bDnaxwR9DWxa+Lb6NPKvdl5B02zDJ/Buv55rg/MRvuMKUXckXfI96hpM0XMtj0MXen3vzWkrWk/wDzzlPyk+zdP5Uo12809/LvEMiDuev4GvPk1JDwx2n9Kvwauyp5bkSRf3W5H4elQ4o1Un1PQ7bWra7XdBJhhyQeCK6Gx1DTdYK2mvHyZm4i1BOGU9hJ/eHueR+o8VlRmcS6fMUkHIQnB/A1d0rxG5k+zXo2TDjnjNJNxeg5RjNWaPUPEGg32g3AS6XfCx/dzJyr/wCB9qzUaun+HXii31O3HhzXSstvKNtrJIfuntGT6eh7Hj0xW8S+HpdEvSnLWzk+W5/kff8AnXXSrc/uy3PLxOG9n70djHU1KvNKkVWI4a3OS5GEpRFntVxIPWp0gHpSC5nC3z0FOFofStZIRUqxL6UXAxhZ+1OFl7VtiJaeI19KLgYX2H2oNh7VviNfSjy19KLgeBbzimmQ0wmkNWSKZDTTIfakxTSppDQFifSmlqcEpfLpale6R76TeewqXyzS+UaVmVeJFuagu4HWpvK9qTyWP8NJ3LTiVGuJF6Maia8uR91mrQFux7ClFqT2FS0zROKMo3l8ejsKhl+2zffYH6it0WZ9BTlsjU8je5SqpbI5oafcsc78GrMWn3n/AD0BHuK6FLNhViOBl6il7GI3ipdDmjpF3IOCtNTRdSj5jKkema7KJcdVq3GFo9jEX1uaOKSw1GMcwE/7pzU8lnJfxGOeGRLlRlHKkbvbPr/P69e4jRT6VajiU/wih4dPqNY6S3RwWl3t3ZFUulfKnh6+lPBOt2/jnws1rfMH1C3QCQ93X+GQe/r7/WvMFt4WHzRqR7irumgafN5tjm3kKlS0R2kg9RxUSw/8rLWNTVpxNvULCXTb17ecfMvRh0YdiKbGRVATEnLMSfUmpFlroV7annu19DSVgKeJBWcJfelE1MRpiWnCasvz6cJ6QGqJhTxKPWskT+9OE/vRYZrCUUvmisoXHvS/aPegDw/fS7xVMPTg1LmNnTLW4etKGFVd1AY0+Yl0y2GFODCqgc07cafML2ZbDinBhVMSU4PRzC5GXlIqRdtUFf3qZXNFx8rLwVakVRVJZD61KspoCzLgRfSnhFqqstSLL70BYtLGKmVBVMS4p4noEXVAqQKvpVET08T4pisX0RKmTA6E1mi4p4uPei4WNdJQO9SiYVii496cLg+tAjbE49acLgetYf2g+tH2k+tAG99pHrR9pHrWD9pPrR9pPrQBvi596UXIrAF0fWnC6PrQBvi496X7R71gi696d9r96Qzd+0+9Ibn3rD+1+9NN570Af//Z','image/jpeg','administradores');
/*!40000 ALTER TABLE `imagenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modulos`
--

DROP TABLE IF EXISTS `modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `padre_id` int(11) DEFAULT '0',
  `permisos_clave` varchar(45) DEFAULT '*',
  `titulo` varchar(60) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `glyphicon` varchar(45) DEFAULT NULL,
  `posicion` int(2) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_modulos_permisos1_idx` (`permisos_clave`),
  CONSTRAINT `fk_modulos_permisos1` FOREIGN KEY (`permisos_clave`) REFERENCES `permisos` (`clave`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modulos`
--

LOCK TABLES `modulos` WRITE;
/*!40000 ALTER TABLE `modulos` DISABLE KEYS */;
INSERT INTO `modulos` VALUES (1,0,'config','Configuraciones',NULL,'fa fa-cogs',90),(2,1,'administradores_root','Administradores','/administradores/administradores','entypo-user',2),(16,1,'administradores_root','Departamentos','/administradores/departamentos','entypo-users',2);
/*!40000 ALTER TABLE `modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permisos`
--

DROP TABLE IF EXISTS `permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clave` varchar(45) NOT NULL,
  `titulo` varchar(60) NOT NULL,
  PRIMARY KEY (`id`,`clave`),
  UNIQUE KEY `clave_UNIQUE` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permisos`
--

LOCK TABLES `permisos` WRITE;
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` VALUES (1,'config','ROOT | Acceso a configuraciones'),(2,'gruposhoteleros_index','ADMIN | Acceso grupos hoteleros'),(3,'clasificacionhoteles_index','ADMIN | Acceso a la clasificacion de hoteles'),(4,'administradores_root','ADMIN | CRUD de administradores y departamentos'),(7,'clientes_index','ADMIN | Acceso a clientes'),(10,'administrar_permisos','ROOT | Administrar permisos'),(11,'gruposhoteleros_edit','ADMIN | Crear/Editar grupos de hoteles'),(12,'gruposhoteleros_delete','ADMIN | Eliminar grupos de hoteles'),(13,'hoteles_index','ADMIN | Acceso a todos los hoteles'),(15,'categoriasdehoteles_edit','ADMIN | Crear/Editar categorias de hoteles'),(16,'categoriasdehoteles_delete','ADMIN | Eliminar categorias de hoteles'),(17,'root','ROOT | Editar configuraciones'),(18,'hoteles_edit_global','ADMIN | CRUD de todos los Hoteles'),(19,'hoteles_edit_own','PROVEEDOR | CRUD Servicios de  Habitaciones  propias y actua'),(20,'hoteles_tarifas','PROVEEDOR | Editar tarifas'),(22,'cms_root','ADMIN | Editar Contenidos, Banners  y Clasificaciones'),(23,'destinos_index','ADMIN | Acceso a destinos'),(24,'destinos_edit','ADMIN | Editar y crear Destinos'),(25,'agencias_root','ADMIN | Control total de Agencias'),(27,'proveedores_access_control','PROVEEDOR | Permite controlar el acceso de proveedores'),(28,'hoteles_edit_markup','ADMIN | Modificar MARKUP'),(29,'tiposproveedores_root','ADMIN | Tipos de proveedores');
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-23 10:41:10
